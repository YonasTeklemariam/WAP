package org.example.Service;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/support")
public class HelloServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Test</title></head><body>");
        out.print("<form method='post'>");
        out.print("<input name ='name' type = 'text' placeholder='Enter your name'/> <br/>");
        out.print("<input name ='email' type = 'text' placeholder='Enter your email address'/> <br/>");
        out.print("<input name ='problem' type = 'text' placeholder='Enter the type of the problem'/> <br/>");
        out.print("<textarea name ='problemDescription' rows=\"4\" cols=\"20\"> Enter problem description </textarea> <br/> ");
        out.print("<input type='submit' value='Help'/>");
        out.print("</form>");
        out.print("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Test</title></head><body>");
        ServletContext sc = this.getServletContext();
        out.print("<p>Thank you! " + req.getParameter("name") + " for contacting us. You should receive reply from us with in 24 hrs in\n" +
                "        your email address: " + req.getParameter("email") + ". Let us know in our support email: "+ sc.getInitParameter("support-email")  +" if\n" +
                "        you don’t receive reply within 24 hrs. Please be sure to attach your reference</p>");
        out.print("</body></html>");
    }
}
